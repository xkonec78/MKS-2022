/*
 * Copyright (c) 2013 - 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"

#include "fsl_power.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Main function
 */
uint32_t strcmp_safe(const char *input, const char *password, uint32_t length)
	{
		uint32_t i;
		uint32_t counter1, counter2 = 0;
		for (i = 0; i < length; i++) {
			if (input[i] == password[i]) {
				counter1++;
			} else {
				counter2++;
			}
			return counter2;
		}
	}

int main(void)
{
    char ch;

    /* Init board hardware. */
    /* set BOD VBAT level to 1.65V */
    POWER_SetBodVbatLevel(kPOWER_BodVbatLevel1650mv, kPOWER_BodHystLevel50mv, false);
    /* attach main clock divide to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();
#if !defined(DONT_ENABLE_FLASH_PREFETCH)
    /* enable flash prefetch for better performance */
    SYSCON->FMCCR |= SYSCON_FMCCR_PREFEN_MASK;
#endif
/*
    uint32_t DWT1,DWT2;
    uint32_t a,b,x;
    a = 20;
    b = 400;
    //x = a+b;

    DWT1 = DWT->CYCCNT;
	x = a+b;
	DWT2 = DWT->CYCCNT;
	PRINTF("\r\nCycles in function: %d", DWT2 - DWT1);
*/
		PRINTF("hello world.\r\n");

		//string.h;

	while (1) {

		uint32_t status, length;
		char password[20] = "1234";
		char input[20];
		PRINTF("Enter password: \r\n");
		SCANF("%s", input);
		//status = strcmp(input, password_stored);
		status = strcmp_safe(input, password, length);

		if (status == 0) {
			PRINTF("input: correct \r\n");
		} else {
			PRINTF("input: invalid \r\n");
		}
		PRINTF("input: %s \r\n", input);

		//ch = GETCHAR();
		//PUTCHAR(ch);

	/*	uint32_t DWT1, DWT2;
		uint32_t status;

		char password_stored[20] = "1234";
		char input[20];

		PRINTF("\r\nEnter password: ");
		SCANF("%s", input);
		DWT1 = DWT->CYCCNT;
		status = strcmp(input, password_stored);
		DWT2 = DWT->CYCCNT;
		if (status == 0) {
			PRINTF("\r\ninput: correct");
		} else {
			PRINTF("\r\ninput: invalid");
		}
		PRINTF("\r\ninput: %s", input);
		PRINTF("\r\nCycles in function: %d", DWT2 - DWT1);
*/

    }
}
